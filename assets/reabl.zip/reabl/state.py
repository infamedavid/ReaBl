# state.py

control_state = {
    "sync_enabled": False,
    "osc_running": False,

    "remote_transport": "stopped",   # "playing", "paused", "stopped"
    "remote_time": 0.0,
    "prev_remote_time": 0.0,

    "last_time_recv_perf": 0.0,
    "last_transport_recv_perf": 0.0,

    "desync_sec": 0.0,
    "desync_frames": 0.0,

    "sync_status": "NO_SIGNAL",      # "NO_SIGNAL", "SYNCED", "DRIFT", "RESYNC", "OUT_OF_RANGE"
    "last_seek_target": 0.0,
    "last_error": "",
}


def reset_runtime_state():
    control_state["osc_running"] = False

    control_state["remote_transport"] = "stopped"
    control_state["remote_time"] = 0.0
    control_state["prev_remote_time"] = 0.0

    control_state["last_time_recv_perf"] = 0.0
    control_state["last_transport_recv_perf"] = 0.0

    control_state["desync_sec"] = 0.0
    control_state["desync_frames"] = 0.0

    control_state["sync_status"] = "NO_SIGNAL"
    control_state["last_seek_target"] = 0.0
    control_state["last_error"] = ""


def register():
    reset_runtime_state()


def unregister():
    reset_runtime_state()