# sync_timer.py

import time
import bpy

from .state import control_state, reset_runtime_state
from . import osc_server
from . import transport_sync


_TIMER_REGISTERED = False
_TIMER_NAMESPACE_KEY = "_REABL_SYNC_TIMER_CALLBACK"
_HARD_RESYNC_COOLDOWN_SEC = 0.20


def _now():
    return time.perf_counter()


def _get_props():
    scene = bpy.context.scene
    if scene is None:
        return None
    return scene.reabl


def _set_status(status):
    control_state["sync_status"] = status


def _handle_stopped_or_paused(scene, props):
    remote_time = control_state["remote_time"]
    target_frame = transport_sync.time_to_frame(remote_time, scene)

    moved = transport_sync.set_frame_if_needed(target_frame, scene)
    transport_sync.ensure_stopped()

    control_state["desync_sec"] = 0.0
    control_state["desync_frames"] = 0.0

    if control_state["last_time_recv_perf"] > 0.0:
        _set_status("SYNCED" if not moved else "RESYNC")
    else:
        _set_status("NO_SIGNAL")


def _handle_playing(scene, props):
    last_recv = control_state["last_time_recv_perf"]
    if last_recv <= 0.0:
        control_state["desync_sec"] = 0.0
        control_state["desync_frames"] = 0.0
        transport_sync.ensure_stopped()
        _set_status("NO_SIGNAL")
        return

    timeout_sec = float(props.signal_timeout)
    since_last_time = _now() - last_recv
    if since_last_time > timeout_sec:
        control_state["desync_sec"] = 0.0
        control_state["desync_frames"] = 0.0
        transport_sync.ensure_stopped()
        _set_status("NO_SIGNAL")
        return

    remote_time = control_state["remote_time"]
    elapsed_local = _now() - last_recv
    expected_remote_now = remote_time + elapsed_local

    target_frame = transport_sync.time_to_frame(expected_remote_now, scene)

    if not transport_sync.is_frame_in_animation_range(target_frame, scene):
        transport_sync.ensure_stopped()
        control_state["desync_sec"] = 0.0
        control_state["desync_frames"] = 0.0
        _set_status("OUT_OF_RANGE")
        return

    transport_sync.ensure_playing()

    local_time = transport_sync.get_local_time_seconds(scene)

    error_sec = expected_remote_now - local_time
    fps = transport_sync.get_scene_fps(scene)
    error_frames = error_sec * fps

    control_state["desync_sec"] = error_sec
    control_state["desync_frames"] = error_frames

    hard = float(props.hard_desync_frames)
    soft = float(props.soft_desync_frames)
    now_perf = _now()
    last_resync = control_state.get("last_hard_resync_perf", 0.0)

    if abs(error_frames) >= hard:
        if (now_perf - last_resync) >= _HARD_RESYNC_COOLDOWN_SEC:
            transport_sync.hard_resync_to_frame(target_frame, scene)
            control_state["last_seek_target"] = expected_remote_now
            control_state["last_hard_resync_perf"] = now_perf
            _set_status("RESYNC")
        else:
            _set_status("DRIFT")
    elif abs(error_frames) >= soft:
        _set_status("DRIFT")
    else:
        _set_status("SYNCED")


def _ensure_server_state(props):
    want_enabled = bool(props.sync_enabled)
    port = int(props.osc_port)

    if want_enabled:
        if not osc_server.is_server_running():
            ok, msg = osc_server.start_osc_server(port)
            control_state["osc_running"] = bool(ok)
            control_state["last_error"] = "" if ok else str(msg)
        else:
            control_state["osc_running"] = True
            control_state["last_error"] = ""
    else:
        if osc_server.is_server_running():
            osc_server.stop_osc_server()
        control_state["osc_running"] = False
        control_state["last_error"] = ""
        _set_status("NO_SIGNAL")


def sync_timer_callback():
    scene = bpy.context.scene
    if scene is None:
        return 0.1

    props = _get_props()
    if props is None:
        return 0.1

    if not osc_server.dependencies_ok():
        if osc_server.is_server_running():
            osc_server.stop_osc_server()

        control_state["osc_running"] = False
        control_state["sync_enabled"] = False
        control_state["last_error"] = osc_server.get_dependency_error_message()
        _set_status("NO_SIGNAL")
        return 0.1

    if not props.sync_enabled:
        if osc_server.is_server_running():
            osc_server.stop_osc_server()

        if control_state["sync_enabled"] or control_state["osc_running"]:
            reset_runtime_state()
            control_state["sync_enabled"] = False

        return 0.1

    control_state["sync_enabled"] = True

    _ensure_server_state(props)

    remote_transport = control_state["remote_transport"]

    if remote_transport in {"stopped", "paused"}:
        _handle_stopped_or_paused(scene, props)
    elif remote_transport == "playing":
        _handle_playing(scene, props)
    else:
        transport_sync.ensure_stopped()
        _set_status("NO_SIGNAL")

    return 0.05


def register_sync_timer():
    global _TIMER_REGISTERED

    old_cb = bpy.app.driver_namespace.get(_TIMER_NAMESPACE_KEY)
    if old_cb is not None:
        try:
            bpy.app.timers.unregister(old_cb)
        except Exception:
            pass

    try:
        bpy.app.timers.unregister(sync_timer_callback)
    except Exception:
        pass

    bpy.app.timers.register(sync_timer_callback, persistent=True)
    bpy.app.driver_namespace[_TIMER_NAMESPACE_KEY] = sync_timer_callback
    _TIMER_REGISTERED = True


def unregister_sync_timer():
    global _TIMER_REGISTERED

    cb = bpy.app.driver_namespace.pop(_TIMER_NAMESPACE_KEY, None)
    if cb is None:
        cb = sync_timer_callback

    try:
        bpy.app.timers.unregister(cb)
    except Exception:
        pass

    _TIMER_REGISTERED = False


def register():
    register_sync_timer()


def unregister():
    unregister_sync_timer()